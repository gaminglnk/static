Just use the Unlock Minecraft Folder and open x64 for 64-bit PC and x86 for 32-bit PC.
At last, run the M_Centres.exe and click Activate.